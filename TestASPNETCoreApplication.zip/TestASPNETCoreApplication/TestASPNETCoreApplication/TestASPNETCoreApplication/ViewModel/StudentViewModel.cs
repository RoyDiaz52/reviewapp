﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestASPNETCoreApplication.Models;

namespace TestASPNETCoreApplication.ViewModel
{
    public class StudentViewModel
    {

        public StudentViewModel()
        {

        }
        public StudentViewModel(Student student)
        {
            Id = student.Id;
            Name = student.Name;
            City = student.City;
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public List<StudentViewModel> StudentList { get; set; }
        public int TotalCount { get; set; }
    }
}
